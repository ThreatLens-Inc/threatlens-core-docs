
#!/usr/bin/env bash
set -euo pipefail

if [ $# -lt 1 ]; then
  echo "Usage: $0 /path/to/local/clone [branch-name]"
  exit 1
fi

REPO_DIR="$1"
BRANCH="${2:-pages-actions}"

if [ ! -d "$REPO_DIR/.git" ]; then
  echo "ERROR: $REPO_DIR does not look like a git repo (missing .git)."
  exit 1
fi

# Ensure target dirs
mkdir -p "$REPO_DIR/docs/assets"
mkdir -p "$REPO_DIR/.github/workflows"

# Copy files from this script folder (assumes you placed docs/ and .github/ next to it)
# If you're running this from your Downloads folder after extracting the bundle, just pass your repo path.
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Prefer bundled files shipped with this script if present
SRC_DOCS="$SCRIPT_DIR/threatlens_core_docs_pages/docs"
SRC_WF="$SCRIPT_DIR/threatlens_core_docs_pages/.github/workflows/deploy-pages.yml"
ALT_DOCS="$SCRIPT_DIR/docs"
ALT_WF="$SCRIPT_DIR/.github/workflows/deploy-pages.yml"

if [ -d "$SRC_DOCS" ]; then
  cp -R "$SRC_DOCS/." "$REPO_DIR/docs/"
elif [ -d "$ALT_DOCS" ]; then
  cp -R "$ALT_DOCS/." "$REPO_DIR/docs/"
else
  echo "ERROR: Could not find docs to copy. Place this script alongside the extracted bundle or provide docs/ next to it."
  exit 1
fi

if [ -f "$SRC_WF" ]; then
  cp "$SRC_WF" "$REPO_DIR/.github/workflows/deploy-pages.yml"
elif [ -f "$ALT_WF" ]; then
  cp "$ALT_WF" "$REPO_DIR/.github/workflows/deploy-pages.yml"
else
  echo "ERROR: Could not find workflow file."
  exit 1
fi

cd "$REPO_DIR"
git checkout -b "$BRANCH" || git checkout "$BRANCH"
git add docs .github/workflows/deploy-pages.yml
git commit -m "ci(pages): deploy docs via GitHub Actions + OG image"
git push origin "$BRANCH"

echo
echo "Branch '$BRANCH' pushed. Open a PR on GitHub, merge to main, and GitHub Actions will deploy Pages."
echo "If Pages is not already set to 'GitHub Actions', go to Settings → Pages and set Source to GitHub Actions."
